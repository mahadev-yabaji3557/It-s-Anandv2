#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Adafruit_Fingerprint.h>
#include <ESP32Servo.h>

/* LCD */
LiquidCrystal_I2C lcd(0x27,16,2);

/* Fingerprint */
HardwareSerial mySerial(2);
Adafruit_Fingerprint finger(&mySerial);

/* Servo */
Servo door;

/* WIFI */
const char* ssid="YOUR_WIFI";
const char* password="YOUR_PASSWORD";

/* Firebase */
String firebaseHost="https://smart-classroom-attendan-12911-default-rtdb.asia-southeast1.firebasedatabase.app";

/* Pins */
int servoPin=18;
int buzzer=23;
int irEntry=27;
int irExit=26;

/* ID ranges */
int studentID=1;
int facultyID=101;

/* ---------------- SETUP ---------------- */

void setup()
{

Serial.begin(115200);

lcd.init();
lcd.backlight();

pinMode(buzzer,OUTPUT);
pinMode(irEntry,INPUT_PULLUP);
pinMode(irExit,INPUT_PULLUP);

door.attach(servoPin);
door.write(0);

/* Fingerprint */

mySerial.begin(57600,SERIAL_8N1,16,17);
finger.begin(57600);

if(!finger.verifyPassword())
{
Serial.println("Fingerprint error");
while(1);
}

/* WIFI */

lcd.clear();
lcd.print("Connecting WiFi");

WiFi.begin(ssid,password);

while(WiFi.status()!=WL_CONNECTED)
{
delay(500);
Serial.print(".");
}

lcd.clear();
lcd.print("System Ready");
delay(2000);

showMenu();

}

/* ---------------- LOOP ---------------- */

void loop()
{

checkSerialCommands();
scanFingerprint();
detectExit();

}

/* ---------------- MENU ---------------- */

void showMenu()
{

Serial.println("Commands:");
Serial.println("S = Enroll Student");
Serial.println("F = Enroll Faculty");
Serial.println("D = Delete Fingerprint");

}

/* ---------------- SERIAL COMMAND ---------------- */

void checkSerialCommands()
{

if(!Serial.available()) return;

char cmd=Serial.read();

if(cmd=='S'||cmd=='s') enrollFinger(studentID++,"Student");
if(cmd=='F'||cmd=='f') enrollFinger(facultyID++,"Faculty");
if(cmd=='D'||cmd=='d') deleteFinger();

}

/* ---------------- ENROLL ---------------- */

void enrollFinger(int id,String role)
{

Serial.println("Enter Name:");

while(!Serial.available());

String name=Serial.readStringUntil('\n');
name.trim();

lcd.clear();
lcd.print("Place Finger");

while(finger.getImage()!=FINGERPRINT_OK);
finger.image2Tz(1);

lcd.clear();
lcd.print("Remove Finger");
delay(2000);

while(finger.getImage()!=FINGERPRINT_OK);
finger.image2Tz(2);

if(finger.createModel()!=FINGERPRINT_OK) return;

if(finger.storeModel(id)==FINGERPRINT_OK)
{

saveUserToFirebase(id,name,role);

lcd.clear();
lcd.setCursor(0,0);
lcd.print("ID:");
lcd.print(id);

lcd.setCursor(0,1);
lcd.print(name);

delay(3000);

}

}

/* ---------------- DELETE ---------------- */

void deleteFinger()
{

Serial.println("Enter ID:");

while(!Serial.available());

int id=Serial.parseInt();

finger.deleteModel(id);

Serial.println("Deleted");

}

/* ---------------- SCAN ---------------- */

void scanFingerprint()
{

if(finger.getImage()!=FINGERPRINT_OK) return;
if(finger.image2Tz()!=FINGERPRINT_OK) return;

if(finger.fingerFastSearch()!=FINGERPRINT_OK)
{

lcd.clear();
lcd.print("Invalid Finger");
denyAccess();
return;

}

int id=finger.fingerID;

processUser(id);

}

/* ---------------- GET USER DATA ---------------- */

void getUserData(int id,String &name,String &role,bool &od)
{

WiFiClientSecure client;
client.setInsecure();

HTTPClient https;

String url=firebaseHost+"/users/"+String(id)+".json";

name="Unknown";
role="Unknown";
od=false;

if(https.begin(client,url))
{

int httpCode=https.GET();

if(httpCode==200)
{

String payload=https.getString();

int nameStart=payload.indexOf("\"name\":\"")+8;
int nameEnd=payload.indexOf("\"",nameStart);

int roleStart=payload.indexOf("\"role\":\"")+8;
int roleEnd=payload.indexOf("\"",roleStart);

int odIndex=payload.indexOf("\"od\":true");

if(nameStart>7)
name=payload.substring(nameStart,nameEnd);

if(roleStart>7)
role=payload.substring(roleStart,roleEnd);

if(odIndex!=-1)
od=true;

}

https.end();

}

}

/* ---------------- PROCESS USER ---------------- */

void processUser(int id)
{

String name,role;
bool od=false;

getUserData(id,name,role,od);

lcd.clear();
lcd.setCursor(0,0);
lcd.print(name);
lcd.setCursor(0,1);
lcd.print(role);

delay(1500);

/* OD Student */

if(od)
{

lcd.clear();
lcd.print("OD Student");

logAttendance(id,"OD");

openDoor();
delay(3000);
closeDoor();
return;

}

/* Faculty */

if(role=="Faculty")
{

lcd.clear();
lcd.print("Lecture Start");

openDoor();
delay(3000);
closeDoor();

return;

}

/* Student */

verifyEntry(id);

}

/* ---------------- ENTRY VERIFY ---------------- */

void verifyEntry(int id)
{

openDoor();

unsigned long startTime=millis();
bool entered=false;

while(millis()-startTime<5000)
{

if(digitalRead(irEntry)==LOW)
{
entered=true;
break;
}

delay(10);

}

if(entered)
{

lcd.clear();
lcd.print("Entry OK");

logAttendance(id,"Present");

}
else
{

lcd.clear();
lcd.print("Door Closing");

}

closeDoor();

}

/* ---------------- EXIT SENSOR ---------------- */

void detectExit()
{

if(digitalRead(irExit)==LOW)
{

lcd.clear();
lcd.print("Exit Detected");

delay(1500);

}

}

/* ---------------- DOOR ---------------- */

void openDoor()
{
door.write(90);
delay(300);
}

void closeDoor()
{
door.write(0);
delay(300);
}

/* ---------------- DENY ---------------- */

void denyAccess()
{

for(int i=0;i<3;i++)
{

digitalWrite(buzzer,HIGH);
delay(200);
digitalWrite(buzzer,LOW);
delay(200);

}

}

/* ---------------- SAVE USER ---------------- */

void saveUserToFirebase(int id,String name,String role)
{

WiFiClientSecure client;
client.setInsecure();

HTTPClient https;

String url=firebaseHost+"/users/"+String(id)+".json";

if(https.begin(client,url))
{

https.addHeader("Content-Type","application/json");

String json="{";
json+="\"name\":\""+name+"\",";
json+="\"role\":\""+role+"\"";
json+="}";

https.PUT(json);

https.end();

}

}

/* ---------------- ATTENDANCE ---------------- */

void logAttendance(int id,String status)
{

WiFiClientSecure client;
client.setInsecure();

HTTPClient https;

String url=firebaseHost+"/attendance/"+String(id)+".json";

if(https.begin(client,url))
{

https.addHeader("Content-Type","application/json");

String json="\""+status+"\"";

https.PUT(json);

https.end();

}

}